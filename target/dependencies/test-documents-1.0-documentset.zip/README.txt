Installer NG test document
==========================

This is the content of Installer NG testing documentation.

If you can read this under target/documents, then the last step of the installation has succeeded. Huzzah!
